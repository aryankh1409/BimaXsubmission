# Assignment (BimaXpress) By ISHAN INDRANIYA

1. Download Project ZIP & Un-zip it
2. In project folder right click and open powershell
(Step 3 only if you skip downloading from github repository, else not required)
3. write cmd 'npm install'
4. Write cmd 'npm start'
5. Again open project folder & open backend folder
6. Write click and open powershell to write cmd 'nodemon server'

If error message like 'nodemon.ps1 cannot be loaded because running scripts is disabled on this system.' while executing cmd 'nodemon server' apper then you require to set scripts to unrestricted.
Open Powershell and enter
1. 'Get-ExecutionPolicy':- 
    You should get 'Restricted'
3. Run this command to make it unrestricted:- 
   'Set-ExecutionPolicy Unrestricted'
3. Again check execution policy changed by running this command:-
    'Get-ExecutionPolicy', 
    You should get Unrestricted

You can now run 'nodemon server'

(In case of any issue with backend try cmd also:
1. 'npm install express cors mangoose dotenv'
2. 'npm install nodemon'
)



Here are few screenshots of Project work and cmd:
![image](https://user-images.githubusercontent.com/54826738/143004062-a9e95794-dabc-474e-8f68-9fe526db6756.png)

![image](https://user-images.githubusercontent.com/54826738/143004106-613f5bca-d7ad-4e73-b15c-1a44dbcabe62.png)

![image](https://user-images.githubusercontent.com/54826738/143004365-13a53617-3600-45e8-99d3-c7df8dcc48a2.png)

![image](https://user-images.githubusercontent.com/54826738/143004412-f95d33f8-de93-439f-96db-bd8764b65b8e.png)

![image](https://user-images.githubusercontent.com/54826738/143004557-6d43f19e-bc70-42b8-a4c2-1e979a080664.png)

![image](https://user-images.githubusercontent.com/54826738/143004589-a5d9bbb5-7b5d-4536-b36f-3b810807079c.png)

![image](https://user-images.githubusercontent.com/54826738/143004633-510dddd4-f1b4-4c92-9106-50a31b839f18.png)
